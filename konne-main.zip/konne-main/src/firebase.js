// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDnTGiFvBO3b-b-xdp_1pEh145URDoDij0",
  authDomain: "konnex-27474.firebaseapp.com",
  projectId: "konnex-27474",
  storageBucket: "konnex-27474.appspot.com",
  messagingSenderId: "252962032617",
  appId: "1:252962032617:web:2cacae70c08200959e5978",
  measurementId: "G-JP82H2QMDX",
};

export default firebaseConfig;
