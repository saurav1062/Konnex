export const homeObjOne = {
  lightBg: false,
  lightText: true,
  lightTextDesc: true,
  topLine: "Exclusive Access",
  headline: "Only for employees",
  description: "Now you can report any data security or data breach instantly",
  buttonLabel: "Report Now",
  imgStart: "",
  img: require("../../images/svg-1.svg"),
  alt: "Credit Card",
};
