export const homeObjThree = {
  lightBg: true,
  lightText: false,
  lightTopLine: true,
  lightTextDesc: false,
  topLine: "User friendly advanced AI Bot",
  headline: "Meet Rebecka",
  description:
    "Your one stop solution to all your work from home related queries",
  buttonLabel: "Chat Now",
  imgStart: "start",
  img: require("../../images/svg-1.svg"),
  alt: "Vault",
};
